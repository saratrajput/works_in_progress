#define SECRET_SSID  "<your_ssid>"
#define SECRET_PASS  "<your_password>"
#define BROKER_USERNAME  "<your_broker_client_username>"
#define BROKER_PASSWORD  "<your_broker_client_password>"
#define BROKER_IP  "<your_broker_ip"
#define CLIENT_NAME  "<your_client_name>"
#define BROKER_PORT  1883
